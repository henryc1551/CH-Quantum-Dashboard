
console.log('Quantum Dashboard działa!');
